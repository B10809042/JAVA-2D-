import java.awt.*;
import javax.swing.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.*;
import javax.imageio.*;
import java.util.*;


public class FinalProject extends JFrame implements MouseListener {

    JLabel start,help,exit;

    public FinalProject(String title) {
        super(title);
        start = new JLabel(new ImageIcon("Image/hh1.png"));//ImageIcon:圖示
        start.setBounds(500,200,187,93);
        start.setEnabled(false);//false按鈕為灰色
        start.addMouseListener(this);
        this.add(start);

        help = new JLabel(new ImageIcon("Image/hh2.png"));
        help.setBounds(500,300,187,93);
        help.setEnabled(false);
        help.addMouseListener(this);
        this.add(help);

        exit = new JLabel(new ImageIcon("Image/hh3.png"));
        exit.setBounds(500,400,187,93);
        exit.setEnabled(false);
        exit.addMouseListener(this);
        this.add(exit);

        MainPanel panel = new MainPanel();
        this.add(panel);
        this.setSize(1200,730);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public static void main(String[] args) {
        new FinalProject("開始畫面");
    }

    class MainPanel extends JPanel{//建立的MainPanel
        Image background;
        public MainPanel() {
            try {
                background = ImageIO.read(new File("Image/images.png"));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        @Override
        public void paint(Graphics g) {
            super.paint(g);
            g.drawImage(background, 480, 0,225,224, null);
        }
    }


    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource().equals(start)){
            //跳轉到下一介面
            new WindowFrame("載入中").Start();
            //關閉當前介面
            dispose();
        }else if(e.getSource().equals(exit)){
            dispose();
        }else if(e.getSource().equals(help)){
            JOptionPane.showMessageDialog(null, "是要有什麼幫助");
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {// TODO Auto-generated method stub
         }

    @Override
    public void mouseReleased(MouseEvent e) {// TODO Auto-generated method stub
         }

    @Override
    public void mouseEntered(MouseEvent e) {
        // 滑鼠移入
        if(e.getSource().equals(start)){//e.getSource()獲取事件
            start.setEnabled(true);
        }else if(e.getSource().equals(help)){
            help.setEnabled(true);
        }else if(e.getSource().equals(exit)){
            exit.setEnabled(true);
        }
    }

    @Override
    public void mouseExited(MouseEvent e) {
        //滑鼠移出
        if(e.getSource().equals(start)){
            start.setEnabled(false);
        }else if(e.getSource().equals(help)){
            help.setEnabled(false);
        }else if(e.getSource().equals(exit)){
            exit.setEnabled(false);
        }
    }
}


class WindowFrame extends JFrame implements Runnable{
    JLabel background;
    //進度條
    JProgressBar jdt;

    //建立一個執行緒
    public void Start(){
        Thread t = new Thread(this);
        t.start();
    }

    public WindowFrame(String title) {
        super(title);
        background = new JLabel(new ImageIcon("Image/hhb.png"));
        this.add(BorderLayout.NORTH,background);

        jdt = new JProgressBar();
        jdt.setStringPainted(true);//載入以字串形式
        jdt.setBackground(Color.ORANGE);
        this.add(BorderLayout.SOUTH,jdt);

        this.setSize(568,340);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(3);
        this.setVisible(true);
    }

    @Override
    public void run() {
        int [] values = {0,1,3,10,23,32,40,47,55,66,76,86,89,95,99,99,99,100};

        for(int i=0; i<values.length; i++){
            jdt.setValue(values[i]);
            try {
                Thread.sleep(200);

            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        dispose();
        new GameFrame1("寵物機");
    }
}


class GameFrame1 extends JFrame {
    public static int score;
    public static int food;
    public static final int WIDTH = 1080;
    public static final int HEIGHT = 800;

    public GameFrame1(String title) {
        super(title);

        GamePanel1 panel = new GamePanel1();
        panel.action();
        this.addMouseListener(panel);
        this.add(panel);

        this.setSize(WIDTH, HEIGHT);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    class GamePanel1 extends JPanel implements MouseListener {
        Chicken chicken;
        JLabel interactive, feed, play;
        JProgressBar jdt1;
        JProgressBar jdt2;
        JProgressBar jdt3;

        public GamePanel1() {
            chicken = new Chicken();
            interactive = new JLabel(new ImageIcon("Image/hhp4.png"));
            interactive.setBounds(800, 100, 187, 93);
            interactive.setEnabled(false);
            interactive.addMouseListener(this);
            this.add(interactive);

            feed = new JLabel(new ImageIcon("Image/hhp5.png"));
            feed.setBounds(800, 100, 187, 93);
            feed.setEnabled(false);
            feed.addMouseListener(this);
            this.add(feed);

            play = new JLabel(new ImageIcon("Image/hhp6.png"));
            play.setBounds(800, 100, 187, 93);
            play.setEnabled(false);
            play.addMouseListener(this);
            this.add(play);
            JLabel jLabel = new JLabel("                                                                                                                                                                  ");
            this.add(jLabel);

            JLabel jLabel1 = new JLabel("好感度");
            this.add(jLabel1);
            jdt1 = new JProgressBar();
            jdt1.setStringPainted(true);
            jdt1.setBackground(Color.yellow);
            this.add(jdt1);

            JLabel jLabel2 = new JLabel("飢餓度");
            this.add(jLabel2);
            jdt2 = new JProgressBar();
            jdt2.setStringPainted(true);
            jdt2.setBackground(Color.orange);
            this.add(jdt2);

            JLabel jLabel3 = new JLabel("肥胖度");
            this.add(jLabel3);
            jdt3 = new JProgressBar();
            jdt3.setStringPainted(true);
            jdt3.setBackground(Color.green);
            this.add(jdt3);
        }

        @Override
        public void paint(Graphics g) {
            super.paint(g);
            chicken.paintPerson(g);
        }
        public void action() {
            new Thread() {
                public void run() {
                    while (flag) {
                        jdt1.setValue(index1);
                        jdt2.setValue(index2);
                        jdt3.setValue(index3);
                        if (flag) {
                            time();
                            gameOverAction();
                            picture();
                        }
                        //重繪方法
                        repaint();
                        try {
                            Thread.sleep(50);
                        } catch (Exception e) {
                            // TODO: handle exception
                            e.printStackTrace();
                        }
                    }
                }
            }.start();//執行緒啟動
        }

        int index = 0;
        int index1 =20;
        int index2 =50;
        int index3 =30;
        public void time(){
            index++;
            if(index%100==0){
                index1--;
            }
            if (index%60==0){
                index2++;
            }
            if(index%80==0){
                index3--;
            }
            index1=index1+score/3;
            index2=index2+score/2;
            index3=index3-score/3;
            if (score !=0){
                score=0;
                index2=index2-food;
                food=0;
            }
        }

        public  void picture(){
            if(index % 300==0){
                chicken.picture();
            }
        }
        public  void gameOverAction(){
            if(index1<=0 || index2>=100 || index3>=100 || index3<=0){
                isGameOver = true;
                JOptionPane.showMessageDialog(null, "你的雞死了");
            }
        }

        public  boolean isGameOver = false;
        boolean flag = true;

        @Override
        public void mouseClicked(MouseEvent e) {
            if (e.getSource().equals(interactive)) {
                chicken.interactive();
                if (index1<=50){index1=index1+3;}
            } else if (e.getSource().equals(feed)) {
                chicken.feed();
                index1=index1+5;
                index2=index2-10;
                index3=index3+20;
            } else if (e.getSource().equals(play)) {
                new GameFrame("跑步機");
                chicken.play();
            }
            if (e.getSource().equals(chicken)){
                chicken.click();
            }
        }

        @Override
        public void mousePressed(MouseEvent e) {
        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }

        @Override
        public void mouseEntered(MouseEvent e) {
            if (e.getSource().equals(interactive)) {//e指一個事件。e.getSource()獲取事件
                interactive.setEnabled(true);
            } else if (e.getSource().equals(feed)) {
                feed.setEnabled(true);
            } else if (e.getSource().equals(play)) {
                play.setEnabled(true);
            }
        }

        @Override
        public void mouseExited(MouseEvent e) {
            if (e.getSource().equals(interactive)) {
                interactive.setEnabled(false);
            } else if (e.getSource().equals(feed)) {
                feed.setEnabled(false);
            } else if (e.getSource().equals(play)) {
                play.setEnabled(false);
            }
        }

        class Chicken {
            private Image image;
            private Image[] images;

            public static final int WIDTH = 180;
            public static final int HEIGHT = 200;

            private int x, y;
            int index;

            public Chicken() {
                init();
                image = images[0];
                x = 450;
                y = 450;
                index = 0;
            }
            public void play() {
                image = images[1];
            }
            public void feed() {
                image = images[4];
            }

            public void interactive() {
                image = images[3];
            }

            public void picture() {
                int i = (int)(Math.random()*6);
                image = images[i];
            }

            public void click() {
                int i = (int)(Math.random()*6);
                image = images[i];
            }
            public void paintPerson(Graphics g) {
                g.drawImage(image, x, y, WIDTH, HEIGHT, null);
            }

            private void init() {
                images = new Image[6];
                for (int i = 0; i < images.length; i++) {
                    try {//2.5
                        images[i] = ImageIO.read(new File("Image/" + (i + 1) + ".png"));//2.4
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}


class GameFrame extends JFrame {
    public static final int WIDTH=1080;
    public static final int HEIGHT=800;
    public GameFrame(String title) {
        super(title);

        GamePanel panel = new GamePanel();
        panel.action();//啟動的方法
        this.addKeyListener(panel);//就監聽
        this.add(panel);

        this.setSize(WIDTH,HEIGHT);
        this.setLocationRelativeTo(null);
        this.setIconImage(new ImageIcon("Image/115.png").getImage());
        this.setVisible(true);
    }

    class GamePanel extends JPanel implements KeyListener{
        Chicken chicken;
        Image background;

        Barrs_1[] barrs1 = {};
        Barrs_5[] barrs5 = {};
        JLabel jLabel = new JLabel();
        public GamePanel() {
            chicken = new Chicken();
            add(jLabel);
            try {
                background = ImageIO.read(new File("Image/back.png"));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        int x=0;
        @Override
        public void paint(Graphics g) {
            super.paint(g);

            g.drawImage(background, x, 0, GameFrame.WIDTH, GameFrame.HEIGHT, null);
            g.drawImage(background, x+GameFrame.WIDTH, 0, GameFrame.WIDTH, GameFrame.HEIGHT,null);
            g.drawString("剩餘時間："+t, 800, 100);
            chicken.paintPerson(g);
            for(int i =0;i<barrs1.length;i++){
                barrs1[i].paintBarrs(g);
            }
            for(int i = 0;i<barrs5.length;i++){
                barrs5[i].paintBarrs(g);
            }

        }
        public void action(){
            new Thread(){
                public void run() {

                    while(flag){
                        if(flag){
                            enteredAction();//生成了障礙物
                            time();
                            stepAction();//移動
                            pengAction();//玩家和障礙物碰撞
                            gameOverAction();
                        }
                        //重繪方法
                        repaint();
                        try {
                            Thread.sleep(40);
                        } catch (Exception e) {
                            // TODO: handle exception
                            e.printStackTrace();
                        }
                    }

                };
            }.start();//啟動
        }

        int index = 0;
        public void enteredAction(){//不斷生成
            index++;
            if(index%20==0 && index<=300){
                Barrs_1 b1 = new Barrs_1();
                barrs1 =Arrays.copyOf(barrs1,barrs1.length+1);//陣列擴容
                barrs1[barrs1.length-1]= b1;//放到陣列最後一個元素的位置
            }
            else if (index%15==0 && index>300){
                Barrs_1 b1 = new Barrs_1();
                barrs1 =Arrays.copyOf(barrs1,barrs1.length+1);
                barrs1[barrs1.length-1]= b1;
            }
            if(index%50==0){
                Barrs_5 b5 = new Barrs_5();
                barrs5 = Arrays.copyOf(barrs5, barrs5.length +1);
                barrs5[barrs5.length-1] = b5;
            }
        }

        public void stepAction() {
            chicken.step();//切換圖片
            chicken.drop();//下墜
            for(int i =0;i<barrs1.length;i++){
                barrs1[i].step();
                //判斷是否越界，並做越界處理
                if(barrs1[i].outofBounds()){
                    //刪除越界
                    barrs1[i] = barrs1[barrs1.length - 1];//用最後一個元素，覆蓋了
                    barrs1= Arrays.copyOf(barrs1, barrs1.length - 1);//陣列縮容
                }
            }
            for(int i = 0;i<barrs5.length;i++){
                barrs5[i].step();
                if(barrs5[i].outofBounds()){
                    barrs5[i] = barrs5[barrs5.length - 1];
                    barrs5 = Arrays.copyOf(barrs5, barrs5.length - 1);
                }
            }
        }

        public void pengAction() {
            //碰撞
            for (int i = 0; i < barrs1.length; i++) {
                if (chicken.getX() + chicken.WIDTH >= barrs1[i].getX() &&
                        chicken.getX() <= barrs1[i].getX() + Barrs_1.WIDTH &&
                        chicken.getY() + chicken.getHeight() >= barrs1[i].getY()) {
                    //碰撞後的處理
                    if (chicken.getX() + chicken.WIDTH <= barrs1[i].getX() + Barrs_1.WIDTH+35) {
                        //左碰撞
                        chicken.setX(barrs1[i].getX() - Barrs_1.WIDTH);
                    }
                    else {
                        //右碰撞
                        chicken.setX(barrs1[i].getX() + Barrs_1.WIDTH);
                    }
                }
            }
            for(int i = 0;i<barrs5.length;i++){
                if(chicken.getX() + chicken.WIDTH >= barrs5[i].getX() &&
                        chicken.getX() <= barrs5[i].getX()   + Barrs_5.WIDTH  &&
                        chicken .getY() +chicken.getHeight() >= barrs5[i].getY() &&
                        chicken.getY()  <= barrs5[i].getY () + Barrs_5.HEIGHT){
                    if(chicken.getX() + chicken.WIDTH <= barrs5[i].getX() + Barrs_5.WIDTH){
                        //刪除
                        barrs5[i]  = barrs5[barrs5.length - 1];
                        barrs5 = Arrays.copyOf(barrs5, barrs5.length - 1);
                        GameFrame1.food+=1;
                    }
                }
            }
        }

        int index2 =0;
        int t =30;
        public void time(){
            index2++;
            if(index%25==0){
                t--;
                jLabel.setText("剩餘時間："+t);
            }
        }

        public  void gameOverAction(){
            if(chicken.outOfBounds()){
                int s=30-t;
                GameFrame1.score=s;
                int index4 = s/3;
                int index5 = s/2;
                JOptionPane.showMessageDialog(null, "經過"+s+"秒"+"獲得:好感+"+index4+" 飢餓+"+(index5-GameFrame1.food)+" 肥胖-"+index4+" 你吃到"+GameFrame1.food+"個胡蘿蔔");
                flag=false;
                dispose();
            }
            if (t<=0){
                int s=30-t;
                GameFrame1.score=s;
                JOptionPane.showMessageDialog(null, "完美通關 獲得:好感+10 飢餓+"+(15-GameFrame1.food)+" 肥胖-10 你吃到"+GameFrame1.food+"個胡蘿蔔");
                flag=false;
                dispose();
            }
        }
        boolean flag = true;

        @Override
        public void keyTyped(KeyEvent e) {}

        @Override
        public void keyPressed(KeyEvent e) {
            int x = chicken.getX();
            int y = chicken.getY();

            //上
            if(e.getKeyCode() == KeyEvent.VK_UP  &&    y > 10 ) {

                if (y == 450) {
                    Thread thread = new Thread(){
                        public void run(){
                            int h =y;
                            for (int i=1;i<=30;i++){
                                try {
                                    if (i%2==0){chicken.image=ImageIO.read(new File("Image/index4.png"));}
                                    else {chicken.image=ImageIO.read(new File("Image/index5.png"));}
                                } catch (IOException ex) {
                                    ex.printStackTrace();
                                }
                                h=h-5;
                                chicken.setY(h);
                                try {
                                    Thread.sleep(7);
                                } catch (InterruptedException ex) {
                                    ex.printStackTrace();
                                }
                            }
                        }
                    };
                    thread.start();
                }
            }
            //下
            if(e.getKeyCode()== KeyEvent.VK_DOWN  &&    y<=450  ){
                if (y<450){chicken.setY(y+35);}
            }
            //左
            if(e.getKeyCode()==KeyEvent.VK_LEFT    &&   x>=0  ){
                chicken.setX(x-35);

            }
            //右
            if(e.getKeyCode()==KeyEvent.VK_RIGHT){
                chicken.setX(x+25);
                if(x>=GameFrame.WIDTH-Chicken.WIDTH){
                    chicken.setX(GameFrame.WIDTH-Chicken.WIDTH);
                }
            }

            if(e.getKeyCode() == KeyEvent.VK_SPACE){
                flag = !flag;
            }
        }

        @Override
        public void keyReleased(KeyEvent e) {

        }
    }

    class Chicken {
        private Image image;
        private Image[] images;

        public static final int WIDTH = 126;
        public static final int HEIGHT = 120;

        private  int x,y;
        int index;

        public Chicken() {
            init();
            image = images[0];
            x = 90;
            y = 450;//地板
            index = 0;
        }
        public void drop() {
            if(y<450){// 下落
                y += 10;
            }
        }
        //換圖
        public void step(){
            if (y==450){
                image = images[index ++ /3%images.length];}
        }
        //繪製
        public void paintPerson(Graphics g){
            g.drawImage(image, x, y, WIDTH, HEIGHT, null);
        }

        //越界的
        public boolean outOfBounds(){
            return this.x >= GameFrame.WIDTH || this.x <= -WIDTH;
        }
        private void init() {
            images = new Image[3];
            for(int i = 0; i<images.length; i++){
                try {
                    images[i] = ImageIO.read(new File("Image/index"+(i+1) + ".png"));//2.4
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
        public int getX() {
            return x;
        }

        public void setX(int x) {
            this.x = x;
        }

        public int getY() {
            return y;
        }

        public void setY(int y) {
            this.y = y;
        }

        public int getHeight() {
            return HEIGHT;
        }
    }

    class Barrs_1 {
        private Image image;
        private Image [] images;
        public static final int WIDTH=91;
        public static final int HEIGHT=106;
        private int x,y;
        int  index;
        private int speed;

        public Barrs_1() {//
            images = new Image[2];
            try {
                images[0]=ImageIO.read(new File("image/a2.png"));
                images[1]=ImageIO.read(new File("image/a4.png"));
            } catch (Exception e) {
                // TODO: handle exception
            }
            image = images[0];
            x=GameFrame.WIDTH+100;
            y=475;
            speed =30;
            int i = (int)(Math.random()*2);
            image =images[i];
            index = 0;
        }

        public  void step() {
            x-=speed;
        }

        public void paintBarrs(Graphics g) {
            g.drawImage(image, x,y,WIDTH,HEIGHT, null);
        }
        public boolean outofBounds(){
            return this.x <=-WIDTH;
        }
        public int getX() {
            return x;
        }
        public int getY() {
            return y;
        }
    }

    class Barrs_5 {
        private Image image;
        public static final int WIDTH = 62;
        public static final int HEIGHT = 68;
        private int x,y;
        private int speed;
        public Barrs_5() {
            try {
                image = ImageIO.read(new File("Image/food.png"));
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            x = GameFrame.WIDTH + 10;
            y = (int) (Math.random()*150+300);
            speed = 20;
        }
        public void step(){
            x -= speed;
        }
        public void paintBarrs(Graphics g){
            g.drawImage(image, x, y, WIDTH, HEIGHT, null);
        }
        public boolean outofBounds() {
            return this.x<=-WIDTH;
        }
        public int getX() {
            return x;
        }
        public int getY() {
            return y;
        }
    }
}
